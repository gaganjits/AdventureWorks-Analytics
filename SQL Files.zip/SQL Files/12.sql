-- Query 9: New vs. Returning Customers
-- Compares revenue contribution from first-time buyers vs. repeat customers

-- Step 1: Find each customer's very first purchase date
WITH FirstPurchase AS (
    SELECT 
        CustomerKey,                                      -- Customer ID
        MIN(OrderDate) AS FirstOrderDate                 -- Date of their first-ever order
    FROM Sales
    GROUP BY CustomerKey                                 -- One row per customer
),

-- Step 2: Label each transaction as "New" or "Returning" customer purchase
CustomerType AS (
    SELECT 
        s.OrderNumber,                                    -- Order ID
        s.CustomerKey,                                    -- Customer ID
        s.OrderDate,                                      -- Date of this order
        s.OrderQuantity,                                  -- Quantity purchased
        p.ProductPrice,                                   -- Price per unit
        YEAR(s.OrderDate) AS Year,                       -- Year of this order
        CASE 
            WHEN s.OrderDate = fp.FirstOrderDate THEN 'New Customer'          -- First order = New
            ELSE 'Returning Customer'                                          -- Any other order = Returning
        END AS CustomerType
    FROM Sales s
    JOIN Products p ON s.ProductKey = p.ProductKey      -- Get prices
    JOIN FirstPurchase fp ON s.CustomerKey = fp.CustomerKey  -- Connect to first purchase info
)

-- Step 3: Aggregate results by year and customer type
SELECT 
    Year,                                                 -- Which year
    CustomerType,                                         -- New or Returning
    COUNT(DISTINCT CustomerKey) AS UniqueCustomers,      -- Number of unique customers
    COUNT(DISTINCT OrderNumber) AS TotalOrders,          -- Number of orders placed
    ROUND(SUM(OrderQuantity * ProductPrice), 2) AS TotalRevenue,  -- Total revenue from this group
    ROUND((SUM(OrderQuantity * ProductPrice) /           -- Calculate % of year's total revenue:
           SUM(SUM(OrderQuantity * ProductPrice)) OVER (PARTITION BY Year)) * 100, 2) AS RevenueShare_Percent
FROM CustomerType
GROUP BY Year, CustomerType                              -- One row per year per customer type
ORDER BY Year, CustomerType;                             -- Sort chronologically