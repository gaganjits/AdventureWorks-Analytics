-- BONUS: Executive Summary Dashboard
-- High-level KPIs - all key business metrics in one row

SELECT 
    COUNT(DISTINCT s.CustomerKey) AS TotalCustomers,                    -- Number of unique customers
    COUNT(DISTINCT s.OrderNumber) AS TotalOrders,                       -- Number of orders placed
    SUM(s.OrderQuantity) AS TotalUnitsSold,                            -- Total products sold
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue,  -- Total money earned
    ROUND(SUM(s.OrderQuantity * p.ProductCost), 2) AS TotalCost,      -- Total cost of goods sold
    ROUND(SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)), 2) AS TotalProfit,  -- Net profit
    ROUND((SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)) /  -- Overall profit margin:
           SUM(s.OrderQuantity * p.ProductPrice)) * 100, 2) AS OverallProfitMargin_Percent,  -- (profit ÷ revenue) × 100
    ROUND(AVG(s.OrderQuantity * p.ProductPrice), 2) AS AvgOrderValue  -- Average revenue per order
FROM Sales s                                                            -- Start with all sales data
JOIN Products p ON s.ProductKey = p.ProductKey;                       -- Connect to products for prices/costs