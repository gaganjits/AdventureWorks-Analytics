USE AdventureWorks;

-- 1. Customers (18,148 rows - ~5 seconds!)
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/converted_AdventureWorks_Customers.csv'
INTO TABLE Customers
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 2. Product_Categories
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/AdventureWorks_Product_Categories.csv'
INTO TABLE Product_Categories
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 3. Product_Subcategories
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/AdventureWorks_Product_Subcategories.csv'
INTO TABLE Product_Subcategories
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 4. Products
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/AdventureWorks_Products.csv'
INTO TABLE Products
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 5. Territories
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/AdventureWorks_Territories.csv'
INTO TABLE Territories
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 6. Sales_2015
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/converted_AdventureWorks_Sales_2015.csv'
INTO TABLE Sales
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 7. Sales_2016
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/converted_AdventureWorks_Sales_2016.csv'
INTO TABLE Sales
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 8. Sales_2017
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/converted_AdventureWorks_Sales_2017.csv'
INTO TABLE Sales
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 9. Returns
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/converted_AdventureWorks_Returns.csv'
INTO TABLE Returns
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;