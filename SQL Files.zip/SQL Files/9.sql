-- Query 6: Profitability by Territory
-- Ranks sales territories by profit margin percentage to find most efficient regions

SELECT 
    t.Region,                                             -- Sales region name
    t.Country,                                            -- Country name
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue,      -- Total sales revenue
    ROUND(SUM(s.OrderQuantity * p.ProductCost), 2) AS TotalCost,          -- Total cost of goods
    ROUND(SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)), 2) AS TotalProfit,  -- Profit = revenue - cost
    ROUND((SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)) /     -- Profit margin calculation:
           SUM(s.OrderQuantity * p.ProductPrice)) * 100, 2) AS ProfitMargin_Percent    -- (profit ÷ revenue) × 100
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for price and cost
JOIN Territories t ON s.TerritoryKey = t.SalesTerritoryKey  -- Connect to territories for region info
GROUP BY t.Region, t.Country                             -- One row per region
ORDER BY ProfitMargin_Percent DESC;                      -- Sort by highest profit margin first (most efficient)