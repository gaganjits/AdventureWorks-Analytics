-- Query 2: Category Performance
-- Ranks product categories by total sales and compares profit margins

SELECT 
    pc.CategoryName,                                     -- Category name (Bikes, Accessories, etc.)
    COUNT(DISTINCT s.OrderNumber) AS TotalOrders,       -- Count unique orders for this category
    SUM(s.OrderQuantity) AS TotalQuantitySold,          -- Total units sold in this category
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue,      -- Revenue = quantity × price
    ROUND(SUM(s.OrderQuantity * p.ProductCost), 2) AS TotalCost,          -- Cost = quantity × cost per unit
    ROUND(SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)), 2) AS TotalProfit,  -- Profit = revenue - cost
    ROUND((SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)) /     -- Profit margin calculation:
           SUM(s.OrderQuantity * p.ProductPrice)) * 100, 2) AS ProfitMargin_Percent    -- (profit ÷ revenue) × 100
FROM Sales s                                             -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for price/cost
JOIN Product_Subcategories ps ON p.ProductSubcategoryKey = ps.ProductSubcategoryKey  -- Connect to subcategories
JOIN Product_Categories pc ON ps.ProductCategoryKey = pc.ProductCategoryKey          -- Connect to categories
GROUP BY pc.CategoryName                                 -- Group by category (one row per category)
ORDER BY TotalRevenue DESC;                              -- Sort by highest revenue first