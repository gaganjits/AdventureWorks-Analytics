-- Query 3A: Top 10 Best-Selling Products
-- Shows the 10 products that generated the most revenue

SELECT 
    p.ProductName,                                        -- Name of the product
    p.ProductSKU,                                         -- Product code/identifier
    SUM(s.OrderQuantity) AS TotalQuantitySold,          -- Total units sold across all orders
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue,      -- Revenue = quantity × price
    ROUND(SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)), 2) AS TotalProfit  -- Profit = revenue - cost
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for details
GROUP BY p.ProductKey, p.ProductName, p.ProductSKU      -- Group by product (one row per product)
ORDER BY TotalRevenue DESC                               -- Sort by highest revenue first
LIMIT 10;                                                 -- Show only top 10 products

-- Query 3B: Bottom 10 Worst-Selling Products
-- Shows the 10 products with the lowest revenue

SELECT 
    p.ProductName,                                        -- Name of the product
    p.ProductSKU,                                         -- Product code/identifier
    SUM(s.OrderQuantity) AS TotalQuantitySold,          -- Total units sold across all orders
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue,      -- Revenue = quantity × price
    ROUND(SUM(s.OrderQuantity * (p.ProductPrice - p.ProductCost)), 2) AS TotalProfit  -- Profit = revenue - cost
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for details
GROUP BY p.ProductKey, p.ProductName, p.ProductSKU      -- Group by product (one row per product)
ORDER BY TotalRevenue ASC                                -- Sort by LOWEST revenue first (ASC = ascending)
LIMIT 10;                                                 -- Show only bottom 10 products