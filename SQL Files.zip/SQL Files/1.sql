-- ========================================
-- ADVENTURE WORKS SQL ANALYSIS PROJECT
-- Part 1: Sales & Operations Intelligence
-- ========================================

-- Create Database
CREATE DATABASE AdventureWorks;
USE AdventureWorks;
SET SESSION sql_mode = '';

CREATE TABLE Customers (
    CustomerKey INT PRIMARY KEY,
    Prefix VARCHAR(10),
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    BirthDate DATE,
    MaritalStatus VARCHAR(1),
    Gender VARCHAR(1),
    EmailAddress VARCHAR(100),
    AnnualIncome VARCHAR(20),
    TotalChildren INT,
    EducationLevel VARCHAR(50),
    Occupation VARCHAR(50),
    HomeOwner VARCHAR(1)
);

CREATE TABLE Product_Categories (
    ProductCategoryKey INT PRIMARY KEY,
    CategoryName VARCHAR(50)
);

CREATE TABLE Product_Subcategories (
    ProductSubcategoryKey INT PRIMARY KEY,
    SubcategoryName VARCHAR(50),
    ProductCategoryKey INT,
    FOREIGN KEY (ProductCategoryKey) REFERENCES Product_Categories(ProductCategoryKey)
);

CREATE TABLE Products (
    ProductKey INT PRIMARY KEY,
    ProductSubcategoryKey INT,
    ProductSKU VARCHAR(50),
    ProductName VARCHAR(100),
    ModelName VARCHAR(50),
    ProductDescription TEXT,
    ProductColor VARCHAR(20),
    ProductSize VARCHAR(20),
    ProductStyle VARCHAR(20),
    ProductCost DECIMAL(10,2),
    ProductPrice DECIMAL(10,2),
    FOREIGN KEY (ProductSubcategoryKey) REFERENCES Product_Subcategories(ProductSubcategoryKey)
);

CREATE TABLE Territories (
    SalesTerritoryKey INT PRIMARY KEY,
    Region VARCHAR(50),
    Country VARCHAR(50),
    Continent VARCHAR(50)
);

CREATE TABLE Sales (
    OrderDate DATE,
    StockDate DATE,
    OrderNumber VARCHAR(50),
    ProductKey INT,
    CustomerKey INT,
    TerritoryKey INT,
    OrderLineItem INT,
    OrderQuantity INT,
    FOREIGN KEY (ProductKey) REFERENCES Products(ProductKey),
    FOREIGN KEY (CustomerKey) REFERENCES Customers(CustomerKey),
    FOREIGN KEY (TerritoryKey) REFERENCES Territories(SalesTerritoryKey)
);

CREATE TABLE Returns (
    ReturnDate DATE,
    TerritoryKey INT,
    ProductKey INT,
    ReturnQuantity INT,
    FOREIGN KEY (TerritoryKey) REFERENCES Territories(SalesTerritoryKey),
    FOREIGN KEY (ProductKey) REFERENCES Products(ProductKey)
);
