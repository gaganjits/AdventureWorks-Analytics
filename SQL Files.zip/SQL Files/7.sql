-- Query 4: Customer Segmentation by Spend
-- Segments customers based on their total lifetime spend into High/Mid/Low tiers

-- Step 1: Calculate each customer's total lifetime spend
WITH CustomerSpend AS (
    SELECT 
        s.CustomerKey,                                    -- Customer ID
        CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,  -- Full customer name
        ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS LifetimeSpend,  -- Total they've ever spent
        COUNT(DISTINCT s.OrderNumber) AS TotalOrders    -- How many orders they've placed
    FROM Sales s
    JOIN Products p ON s.ProductKey = p.ProductKey      -- Get prices
    JOIN Customers c ON s.CustomerKey = c.CustomerKey   -- Get customer names
    GROUP BY s.CustomerKey, c.FirstName, c.LastName     -- One row per customer
),

-- Step 2: Calculate total revenue across all customers
TotalRevenueCalc AS (
    SELECT SUM(LifetimeSpend) AS TotalRevenue FROM CustomerSpend
),

-- Step 3: Assign customers to segments based on spend ranges
Segments AS (
    SELECT 
        cs.*,
        CASE 
            WHEN cs.LifetimeSpend >= 2000 THEN 'High Spender'    -- Customers spending $2000+
            WHEN cs.LifetimeSpend >= 500 THEN 'Mid Spender'      -- Customers spending $500-$1999
            ELSE 'Low Spender'                                    -- Customers spending under $500
        END AS SpendSegment
    FROM CustomerSpend cs
)

-- Step 4: Aggregate results by segment
SELECT 
    SpendSegment,                                         -- High/Mid/Low Spender
    COUNT(*) AS CustomerCount,                           -- Number of customers in segment
    ROUND(SUM(LifetimeSpend), 2) AS SegmentRevenue,    -- Total revenue from this segment
    ROUND((SUM(LifetimeSpend) / (SELECT TotalRevenue FROM TotalRevenueCalc)) * 100, 2) AS RevenueShare_Percent,  -- % of total revenue
    ROUND(AVG(LifetimeSpend), 2) AS AvgLifetimeSpend,  -- Average spend per customer
    ROUND(AVG(TotalOrders), 1) AS AvgOrders            -- Average orders per customer
FROM Segments
GROUP BY SpendSegment                                    -- One row per segment
ORDER BY SegmentRevenue DESC;                            -- Show highest revenue segment first