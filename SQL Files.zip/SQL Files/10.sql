-- Query 7A: Return Rate by Category
-- Shows which product categories have the highest return rates

SELECT 
    pc.CategoryName,                                      -- Product category name
    SUM(s.OrderQuantity) AS TotalSold,                   -- Total units sold in this category
    COALESCE(SUM(r.ReturnQuantity), 0) AS TotalReturned,  -- Total units returned (COALESCE handles NULL = 0)
    ROUND((COALESCE(SUM(r.ReturnQuantity), 0) / SUM(s.OrderQuantity)) * 100, 2) AS ReturnRate_Percent  -- (returns ÷ sold) × 100
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products
JOIN Product_Subcategories ps ON p.ProductSubcategoryKey = ps.ProductSubcategoryKey  -- Connect to subcategories
JOIN Product_Categories pc ON ps.ProductCategoryKey = pc.ProductCategoryKey          -- Connect to categories
LEFT JOIN Returns r ON s.ProductKey = r.ProductKey      -- LEFT JOIN = include products with 0 returns
GROUP BY pc.CategoryName                                 -- One row per category
ORDER BY ReturnRate_Percent DESC;                        -- Sort by highest return rate first

-- Query 7B: Top 10 Products with Highest Return Rates
-- Identifies specific products with the most returns

SELECT 
    p.ProductName,                                        -- Product name
    SUM(s.OrderQuantity) AS TotalSold,                   -- Total units sold
    COALESCE(SUM(r.ReturnQuantity), 0) AS TotalReturned,  -- Total units returned (0 if NULL)
    ROUND((COALESCE(SUM(r.ReturnQuantity), 0) / SUM(s.OrderQuantity)) * 100, 2) AS ReturnRate_Percent  -- Return rate %
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for names
LEFT JOIN Returns r ON s.ProductKey = r.ProductKey      -- LEFT JOIN = include products with 0 returns
GROUP BY p.ProductKey, p.ProductName                     -- One row per product
HAVING TotalReturned > 0                                 -- Only show products that have returns (filter out 0 returns)
ORDER BY ReturnRate_Percent DESC                         -- Sort by highest return rate first
LIMIT 10;                                                 -- Show only top 10 worst products