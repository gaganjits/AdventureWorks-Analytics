-- Query 8A: Monthly Sales Trends
-- Shows sales performance month-by-month to detect seasonal patterns

SELECT 
    YEAR(s.OrderDate) AS Year,                           -- Extract year from order date
    MONTH(s.OrderDate) AS Month,                         -- Extract month number (1-12)
    MONTHNAME(s.OrderDate) AS MonthName,                 -- Month name (January, February, etc.)
    COUNT(DISTINCT s.OrderNumber) AS TotalOrders,       -- Number of orders in this month
    SUM(s.OrderQuantity) AS TotalQuantity,              -- Total units sold this month
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue  -- Total revenue this month
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for prices
GROUP BY YEAR(s.OrderDate), MONTH(s.OrderDate), MONTHNAME(s.OrderDate)  -- One row per month
ORDER BY Year, Month;                                     -- Sort chronologically

-- Query 8B: Quarterly Sales Trends
-- Shows sales performance by quarter (Q1, Q2, Q3, Q4) for broader trend analysis

SELECT 
    YEAR(s.OrderDate) AS Year,                           -- Extract year from order date
    QUARTER(s.OrderDate) AS Quarter,                     -- Extract quarter (1=Q1, 2=Q2, 3=Q3, 4=Q4)
    COUNT(DISTINCT s.OrderNumber) AS TotalOrders,       -- Number of orders this quarter
    SUM(s.OrderQuantity) AS TotalQuantity,              -- Total units sold this quarter
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue  -- Total revenue this quarter
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for prices
GROUP BY YEAR(s.OrderDate), QUARTER(s.OrderDate)        -- One row per quarter
ORDER BY Year, Quarter;                                   -- Sort chronologically