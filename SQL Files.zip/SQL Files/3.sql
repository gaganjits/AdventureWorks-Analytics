SELECT 'Customers' AS TableName, COUNT(*) AS RowCount FROM Customers
UNION ALL
SELECT 'Product_Categories', COUNT(*) FROM Product_Categories
UNION ALL
SELECT 'Product_Subcategories', COUNT(*) FROM Product_Subcategories
UNION ALL
SELECT 'Products', COUNT(*) FROM Products
UNION ALL
SELECT 'Territories', COUNT(*) FROM Territories
UNION ALL
SELECT 'Sales', COUNT(*) FROM Sales
UNION ALL
SELECT 'Returns', COUNT(*) FROM Returns;