-- Query 1: Annual Revenue Trends
-- This calculates total revenue per year and compares growth year-over-year

SELECT 
    YEAR(s.OrderDate) AS Year,                           -- Extract year from order date (e.g., 2015, 2016)
    COUNT(DISTINCT s.OrderNumber) AS TotalOrders,        -- Count unique orders (each order counted once)
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue,  -- Calculate revenue: quantity sold × price per unit
    ROUND((SUM(s.OrderQuantity * p.ProductPrice) /      -- Calculate YoY growth:
          LAG(SUM(s.OrderQuantity * p.ProductPrice))    -- LAG gets previous year's revenue
          OVER (ORDER BY YEAR(s.OrderDate)) - 1) * 100, 2) AS YoY_Growth_Percent  -- Convert to percentage
FROM Sales s                                              -- Start with Sales table
JOIN Products p ON s.ProductKey = p.ProductKey           -- Connect to Products to get prices
GROUP BY YEAR(s.OrderDate)                               -- Group results by year (one row per year)
ORDER BY Year;                                            -- Sort from earliest to latest year