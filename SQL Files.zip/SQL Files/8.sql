-- Query 5: Geographic Sales Leadership
-- Identifies top countries and regions by total sales and average order size

SELECT 
    t.Country,                                            -- Country name
    t.Region,                                             -- Region within country
    t.Continent,                                          -- Continent location
    COUNT(DISTINCT s.OrderNumber) AS TotalOrders,       -- Number of unique orders from this region
    SUM(s.OrderQuantity) AS TotalQuantity,              -- Total units sold in this region
    ROUND(SUM(s.OrderQuantity * p.ProductPrice), 2) AS TotalRevenue,  -- Total revenue from region
    ROUND(AVG(s.OrderQuantity * p.ProductPrice), 2) AS AvgOrderSize   -- Average order value
FROM Sales s                                              -- Start with sales data
JOIN Products p ON s.ProductKey = p.ProductKey          -- Connect to products for prices
JOIN Territories t ON s.TerritoryKey = t.SalesTerritoryKey  -- Connect to territories for location info
GROUP BY t.Country, t.Region, t.Continent               -- One row per region (group by all location fields)
ORDER BY TotalRevenue DESC;                              -- Sort by highest revenue first